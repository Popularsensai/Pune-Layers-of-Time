// Downloads open-licensed photos from Wikimedia Commons into public/img (first run only). Pin a photo by adding "file":"Name.jpg" in media.json.
const fs=require('fs'),path=require('path');
const UA='PuneLayersOfTime/1.0 (educational museum prototype)',dir=path.join(__dirname,'public','img'),idx=path.join(dir,'index.json');
const API='https://commons.wikimedia.org/w/api.php',OK=/^(CC[ -]BY|CC0|Public domain|PD)/i,BAD=/(^|[ -])(NC|ND)([ -]|$)/i;
const strip=s=>String(s||'').replace(/<[^>]*>/g,'').replace(/&amp;/g,'&').replace(/\s+/g,' ').replace(/[<>"]/g,'').trim().slice(0,70);
const get=async(u,t)=>{const r=await fetch(u,{headers:{'User-Agent':UA}});if(!r.ok)throw new Error('HTTP '+r.status);return t?r.arrayBuffer():r.json()};
const load=()=>{try{return JSON.parse(fs.readFileSync(idx,'utf8'))}catch(e){return{}}};
async function find(e,used){
 const b=API+'?action=query&format=json&prop=imageinfo&iiprop=url|mime|size|extmetadata&iiurlwidth=1100';
 const d=await get(e.file?b+'&titles='+encodeURIComponent('File:'+e.file.replace(/^File:/,'')):b+'&generator=search&gsrnamespace=6&gsrlimit=25&gsrsearch='+encodeURIComponent(e.q));
 const pgs=Object.values((d.query&&d.query.pages)||{}).sort((a,b)=>(a.index||0)-(b.index||0));
 for(const p of pgs){const i=p.imageinfo&&p.imageinfo[0];if(!i||i.mime!=='image/jpeg'||i.width<800||used.has(p.title))continue;
  if(!e.file&&e.kw&&!e.kw.some(k=>p.title.toLowerCase().includes(k)))continue;
  const m=i.extmetadata||{},lic=strip(m.LicenseShortName&&m.LicenseShortName.value);if(!OK.test(lic)||BAD.test(lic))continue;
  return{p,i,lic,credit:strip(m.Artist&&m.Artist.value)||'Unknown author'}}return null}
async function sync(log=console.log){const M=JSON.parse(fs.readFileSync(path.join(__dirname,'media.json'),'utf8'));fs.mkdirSync(dir,{recursive:true});
 const out=load(),used=new Set(Object.values(out).map(v=>v.title));
 for(const[k,e]of Object.entries(M)){if(out[k]&&fs.existsSync(path.join(dir,k+'.jpg')))continue;
  try{const r=await find(e,used);if(!r){log(`  photo ${k}: no open-licensed match found (pin one in media.json)`);continue}
   const buf=Buffer.from(await get(r.i.thumburl||r.i.url,1));if(buf.length<5000)throw new Error('empty download');
   fs.writeFileSync(path.join(dir,k+'.jpg'),buf);out[k]={src:'/img/'+k+'.jpg',credit:r.credit,lic:r.lic,title:r.p.title,url:r.i.descriptionurl};used.add(r.p.title);
   fs.writeFileSync(idx,JSON.stringify(out,null,1));log(`  photo ${k}: ${r.p.title} (${r.lic})`)}
  catch(err){log(`  photo ${k}: failed (${err.message})`)}
  await new Promise(r=>setTimeout(r,500))}}
module.exports={sync,load,find};

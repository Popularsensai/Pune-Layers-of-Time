// Offline test of photo selection (keyword match, licence filter, duplicate avoidance) using a fake Commons API.
const assert=require('assert'),fs=require('fs'),path=require('path'),media=require('./media');
const page=(i,t,mime,w,lic,art)=>({title:t,index:i,imageinfo:[{mime,width:w,thumburl:'http://x/'+i+'.jpg',descriptionurl:'http://c/'+i,extmetadata:{LicenseShortName:{value:lic},Artist:{value:art}}}]});
const pages={1:page(1,'File:Random cat.jpg','image/jpeg',2000,'CC BY-SA 4.0','A'),2:page(2,'File:Shaniwar Wada NC.jpg','image/jpeg',2000,'CC BY-NC 4.0','B'),
 3:page(3,'File:Shaniwar Wada plan.svg','image/svg+xml',2000,'CC0','C'),4:page(4,'File:Shaniwar Wada gate.jpg','image/jpeg',2000,'CC BY-SA 4.0','<a href="x">Some &amp; Author</a>')};
global.fetch=async u=>({ok:true,json:async()=>({query:{pages}}),arrayBuffer:async()=>new Uint8Array(9000).buffer});
(async()=>{const e={q:'Shaniwar Wada',kw:['shaniwar']},used=new Set();
 const r=await media.find(e,used);assert.strictEqual(r.p.title,'File:Shaniwar Wada gate.jpg');assert.strictEqual(r.credit,'Some & Author');assert.strictEqual(r.lic,'CC BY-SA 4.0');
 used.add(r.p.title);assert.strictEqual(await media.find(e,used),null);console.log('MEDIA LOGIC OK (keyword, licence, type, no-duplicates, credit cleanup)')})().catch(e=>{console.error(e);process.exit(1)});

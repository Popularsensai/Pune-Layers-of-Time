// Pune: Layers of Time - local pairing server (laptop display <-> phone Time Lens)
const express=require('express'),http=require('http'),https=require('https'),os=require('os'),fs=require('fs'),path=require('path');
const media=require('./media'),{Server}=require('socket.io'),QR=require('qrcode'),selfsigned=require('selfsigned');
const HP=+process.env.HTTP_PORT||3000,SP=+process.env.HTTPS_PORT||3443;
const lan=()=>{const c=[];for(const l of Object.values(os.networkInterfaces()))for(const i of l||[])if(i.family==='IPv4'&&!i.internal)c.push(i.address);
 return c.find(a=>/^(192\.168|10\.|172\.(1[6-9]|2\d|3[01]))/.test(a))||c[0]||'127.0.0.1'};
const ip=process.env.LAN_IP||lan(),base=process.env.PUBLIC_URL||`https://${ip}:${SP}`;
const S=new Map(),A='ABCDEFGHJKMNPQRSTUVWXYZ',mk=()=>{let c;do c=Array.from({length:4},()=>A[Math.random()*A.length|0]).join('');while(S.has(c));return c};
async function cert(){const d=path.join(__dirname,'.cert'),k=path.join(d,'key.pem'),c=path.join(d,'cert.pem'),m=path.join(d,'ip.txt');
 if([k,c,m].every(f=>fs.existsSync(f))&&fs.readFileSync(m,'utf8')===ip)return{key:fs.readFileSync(k),cert:fs.readFileSync(c)};
 const p=await selfsigned.generate([{name:'commonName',value:ip}],{days:365,keySize:2048,algorithm:'sha256',extensions:[{name:'subjectAltName',altNames:[{type:7,ip},{type:7,ip:'127.0.0.1'},{type:2,value:'localhost'}]}]});
 fs.mkdirSync(d,{recursive:true});fs.writeFileSync(k,p.private);fs.writeFileSync(c,p.cert);fs.writeFileSync(m,ip);return{key:p.private,cert:p.cert}}
function wire(io){io.on('connection',s=>{
 s.on('create',(want,ack)=>{const c=want&&S.has(want)?want:mk(),e=S.get(c)||{};e.d=s.id;S.set(c,e);s.data={c,role:'d'};s.join('d:'+c);
  const url=`${base}/?s=${c}`;QR.toDataURL(url,{margin:1,width:320}).then(qr=>ack&&ack({code:c,url,qr,ph:!!e.p}))});
 s.on('join',(c,ack)=>{c=String(c||'').toUpperCase().trim();const e=S.get(c);if(!e)return ack&&ack({ok:false});
  if(e.p&&e.p!==s.id)io.to(e.p).emit('kick');e.p=s.id;s.data={c,role:'p'};s.join('p:'+c);io.to('d:'+c).emit('peer',{up:true});ack&&ack({ok:true})});
 for(const t of ['hello','ptr','sel','ans','ctl','refl'])s.on(t,d=>{const{c,role}=s.data||{};if(c&&role==='p')(t==='ptr'?io.to('d:'+c).volatile:io.to('d:'+c)).emit(t,d)});
 s.on('st',d=>{const{c,role}=s.data||{};if(c&&role==='d')io.to('p:'+c).emit('st',d)});
 s.on('disconnect',()=>{const{c,role}=s.data||{},e=S.get(c);if(!e)return;
  if(role==='p'&&e.p===s.id){e.p=null;io.to('d:'+c).emit('peer',{up:false})}
  if(role==='d'&&e.d===s.id){e.d=null;io.to('p:'+c).emit('gone')}
  if(!e.p&&!e.d)setTimeout(()=>{const x=S.get(c);if(x&&!x.p&&!x.d)S.delete(c)},6e5)})})}
async function start(){const app=express();app.get('/api/media',(q,r)=>r.json(media.load()));app.use(express.static(path.join(__dirname,'public')));app.get('/p',(q,r)=>r.sendFile(path.join(__dirname,'public','index.html')));
 const hs=http.createServer(app),ss=https.createServer(await cert(),app),io=new Server({cors:{origin:true}});io.attach(hs);io.attach(ss);wire(io);
 hs.listen(HP);ss.listen(SP);
 console.log(`\n  Pune: Layers of Time\n  Laptop:  http://localhost:${HP}   (open this on the laptop)\n  Phone:   ${base}   (the QR on the laptop opens this)\n  Both devices must be on the same Wi-Fi. Accept the certificate warning once on the phone.\n`);if(require.main===module&&!process.env.NO_PHOTOS){console.log('  Fetching open-licensed photos from Wikimedia Commons (first run only, needs internet)...');media.sync().then(()=>console.log('  Photo check finished. Refresh the page if a frame is empty.')).catch(e=>console.log('  Photos unavailable:',e.message))}return{hs,ss,io}}
if(require.main===module)start();module.exports={start};

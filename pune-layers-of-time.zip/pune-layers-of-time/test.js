// Pairing smoke test: simulates a laptop display (http) and a phone (https) against the real server.
process.env.HTTP_PORT=3100;process.env.HTTPS_PORT=3543;
const {start}=require('./server'),{io}=require('socket.io-client'),assert=require('assert');
const once=(s,e)=>new Promise(r=>s.once(e,r)),wait=ms=>new Promise(r=>setTimeout(r,ms));
(async()=>{const srv=await start();
 const d=io('http://127.0.0.1:3100'),p=io('https://127.0.0.1:3543',{rejectUnauthorized:false});await Promise.all([once(d,'connect'),once(p,'connect')]);
 const a=await new Promise(r=>d.emit('create',null,r));assert(/^[A-Z]{4}$/.test(a.code)&&a.qr.startsWith('data:image/png')&&a.url.includes('?s='+a.code));console.log('create ok',a.code,a.url);
 assert(!(await new Promise(r=>p.emit('join','ZZZZ',r))).ok);console.log('bad code rejected');
 const up=once(d,'peer');assert((await new Promise(r=>p.emit('join',a.code.toLowerCase(),r))).ok);assert((await up).up);console.log('phone joined, display notified');
 const got=once(d,'ptr');p.emit('ptr',{x:.3,y:.7});assert.deepStrictEqual(await got,{x:.3,y:.7});console.log('phone -> display pointer ok');
 const st=once(p,'st');d.emit('st',{st:'explore'});assert.strictEqual((await st).st,'explore');console.log('display -> phone state ok');
 for(const t of['sel','ans','ctl','refl','hello']){const g=once(d,t);p.emit(t,{t});await g}console.log('select/answer/control events ok');
 const dn=once(d,'peer');p.disconnect();assert(!(await dn).up);console.log('phone drop detected');
 d.disconnect();await wait(100);const d2=io('http://127.0.0.1:3100');await once(d2,'connect');
 const b=await new Promise(r=>d2.emit('create',a.code,r));assert.strictEqual(b.code,a.code);console.log('display reclaims session after reload');
 const html=await (await fetch('http://127.0.0.1:3100/')).text();assert(html.includes('/socket.io/socket.io.js'));
 assert(await new Promise(r=>require('https').get('https://127.0.0.1:3543/socket.io/socket.io.js',{rejectUnauthorized:false},x=>r(x.statusCode==200))));console.log('static + https ok\nALL PAIRING TESTS PASSED');process.exit(0)})().catch(e=>{console.error('FAIL',e);process.exit(1)});
